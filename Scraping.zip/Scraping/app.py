# app.py

from flask import Flask, jsonify
from scraper import fetch_schemes  # assuming your scraping logic is in scraper.py

app = Flask(__name__)

@app.route('/')
def home():
    return "Server is running. Visit /api/schemes to fetch schemes."

@app.route('/api/schemes', methods=['GET'])
def get_schemes():
    schemes = fetch_schemes()
    return jsonify(schemes)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
